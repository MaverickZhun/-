function varargout = ThrippleM_GUI(varargin)
%DOUBLEM_GUI MATLAB code file for DoubleM_GUI.fig
%      DOUBLEM_GUI, by itself, creates a new DOUBLEM_GUI or raises the existing
%      singleton*.
%
%      H = DOUBLEM_GUI returns the handle to a new DOUBLEM_GUI or the handle to
%      the existing singleton*.
%
%      DOUBLEM_GUI('Property','Value',...) creates a new DOUBLEM_GUI using the
%      given property value pairs. Unrecognized properties are passed via
%      varargin to DoubleM_GUI_OpeningFcn.  This calling syntax produces a
%      warning when there is an existing singleton*.
%
%      DOUBLEM_GUI('CALLBACK') and DOUBLEM_GUI('CALLBACK',hObject,...) call the
%      local function named CALLBACK in DOUBLEM_GUI.M with the given input
%      arguments.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help DoubleM_GUI

% Last Modified by GUIDE v2.5 19-Sep-2024 20:57:48

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ThrippleM_GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @ThrippleM_GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
   gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT



%% --- Executes just before DoubleM_GUI is made visible.
function ThrippleM_GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   unrecognized PropertyName/PropertyValue pairs from the
%            command line (see VARARGIN)

% Choose default command line output for DoubleM_GUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes DoubleM_GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);

img = imread('Pantograph_3M_Real.jpeg');
axes(handles.axes7);
imshow(img);

img = imread('Pantograph_3M.png');
axes(handles.axes6);
imshow(img);



%% --- Outputs from this function are returned to the command line.
function varargout = ThrippleM_GUI_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



%% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% 绘制数据图1
axes(handles.axes1);
plot(handles.time1, (handles.signal_woFpc)*100, 'k', 'LineWidth', 1.5);
hold on;
plot(handles.time1, (handles.signal_Fpc)*100, 'r', 'LineWidth', 1.35);
hold off;
legend('WO', 'Ours');
xlabel('Time/S');
ylabel('Fpc/N');
xlim([0,9]);
ylim([0,200]);

% 绘制数据图2
axes(handles.axes2);
plot(handles.time1, handles.signal_wox1, 'k', 'LineWidth', 1.5);
hold on;
plot(handles.time1, handles.signal_x1, 'r', 'LineWidth', 1.35);
hold off;
legend('WO', 'Ours');
xlabel('Time/S');
ylabel('x1/m');
xlim([0,9]);

% 绘制数据图3
axes(handles.axes3);
plot(handles.time1, handles.signal_wox2, 'k', 'LineWidth', 1.5);
hold on;
plot(handles.time1, handles.signal_x2, 'r', 'LineWidth', 1.35);
hold off;
legend('WO', 'Ours');
xlabel('Time/S');
ylabel('x2/m');
xlim([0,9]);

% 绘制数据图4
axes(handles.axes4);
plot(handles.time1, handles.signal_wox3, 'k', 'LineWidth', 1.5);
hold on;
plot(handles.time1, handles.signal_x3, 'r', 'LineWidth', 1.35);
hold off;
legend('WO', 'Ours');
xlabel('Time/S');
ylabel('x3/m');
xlim([0,9]);



%% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% 绘制数据图1
axes(handles.axes1);
plot(handles.signal_Fre_woFpc, (handles.signal_FFT_woFpc)*100, 'k', 'LineWidth', 1.5);
hold on;
plot(handles.signal_Fre_OursFpc, (handles.signal_FFT_OursFpc)*100, 'r', 'LineWidth', 1.35);
hold off;
legend('WO', 'Ours');
xlabel('Frequency/Hz');
ylabel('Magnitude/N');
xlim([0,9]);

% 绘制数据图2
axes(handles.axes2);
plot(handles.signal_Fre_wox1, handles.signal_FFT_wox1, 'k', 'LineWidth', 1.5);
hold on;
plot(handles.signal_Fre_x1, handles.signal_FFT_x1, 'r', 'LineWidth', 1.35);
hold off;
legend('WO', 'Ours');
xlabel('Frequency/Hz');
ylabel('Magnitude/m');
xlim([0,9]);

% 绘制数据图3
axes(handles.axes3);
plot(handles.signal_Fre_wox2, handles.signal_FFT_wox2, 'k', 'LineWidth', 1.5);
hold on;
plot(handles.signal_Fre_x2, handles.signal_FFT_x2, 'r', 'LineWidth', 1.35);
hold off;
legend('WO', 'Ours');
xlabel('Frequency/Hz');
ylabel('Mangnitude/m');
xlim([0,9]);

% 绘制数据图4
axes(handles.axes4);
plot(handles.signal_Fre_wox3, handles.signal_FFT_wox3, 'k', 'LineWidth', 1.5);
hold on;
plot(handles.signal_Fre_x3,  handles.signal_FFT_x3, 'r', 'LineWidth', 1.35);
hold off;
legend('WO', 'Ours');
xlabel('Frequency/Hz');
ylabel('Magnitude/m');
xlim([0,9]);


%% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename, pathname] = uigetfile({'*.xlsx;*.xls'}, 'Select Excel file');
if isequal(filename, 0)
    disp('User selected Cancel');
else
    fullfilename = fullfile(pathname, filename);
    disp(['User selected ', fullfilename]);
    
    % 读取 Excel 文件
    data = readtable(fullfilename);
    
    % 保存数据到 handles 结构
    handles.time1 = data.Time1;
    handles.signal_woFpc = data.woFpc;
    handles.signal_Fpc = data.Fpc;
    handles.signal_wox1 = data.wox1;
    handles.signal_x1 = data.x1;
    handles.signal_wox2 = data.wox2;
    handles.signal_x2 = data.x2;
    handles.signal_wox3 = data.wox3;
    handles.signal_x3 = data.x3;
    handles.signal_Fre_woFpc = data.Fre_woFpc;
    handles.signal_FFT_woFpc = data.FFT_woFpc;
    handles.signal_Fre_OursFpc = data.Fre_OursFpc;
    handles.signal_FFT_OursFpc = data.FFT_OursFpc;
    handles.signal_Fre_wox1 = data.Fre_wox1;
    handles.signal_FFT_wox1 = data.FFT_wox1;
    handles.signal_Fre_x1 = data.Fre_x1;
    handles.signal_FFT_x1 = data.FFT_x1;
    handles.signal_Fre_wox2 = data.Fre_wox2;
    handles.signal_FFT_wox2 = data.FFT_wox2;
    handles.signal_Fre_x2 = data.Fre_x2;
    handles.signal_FFT_x2 = data.FFT_x2;
    handles.signal_Fre_wox3 = data.Fre_wox3;
    handles.signal_FFT_wox3 = data.FFT_wox3;
    handles.signal_Fre_x3 = data.Fre_x3;
    handles.signal_FFT_x3 = data.FFT_x3;

    % 更新 handles 结构
    guidata(hObject, handles);
end



%% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[filename, pathname] = uigetfile({'*.xlsx;*.xls'}, 'Select Excel file');
if isequal(filename, 0)
    disp('User selected Cancel');
else
    fullfilename = fullfile(pathname, filename);
    disp(['User selected ', fullfilename]);
    
    % 读取 Excel 文件
    data = readtable(fullfilename);
    
    % 格式化数据，显示小数点后两位
    formattedData = cell(size(data));
    for row = 1:size(data, 1)
        for col = 1:size(data, 2)
            if isnumeric(data{row, col})
                % 对数值数据进行格式化，保留两位小数
                formattedData{row, col} = sprintf('%.2f', data{row, col});
            else
                % 非数值数据保持不变
                formattedData{row, col} = data{row, col};
            end
        end
    end
    
    % 将格式化后的数据设置到 uitable 控件
    set(handles.uitable1, 'Data', formattedData);
    
    % 更新 handles 结构
    guidata(hObject, handles);
end



%% --- Executes during object deletion, before destroying properties.
function axes5_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to axes5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
