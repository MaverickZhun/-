function varargout = DoubleM_GUI(varargin)
%DOUBLEM_GUI MATLAB code file for DoubleM_GUI.fig
%      DOUBLEM_GUI, by itself, creates a new DOUBLEM_GUI or raises the existing
%      singleton*.
%
%      H = DOUBLEM_GUI returns the handle to a new DOUBLEM_GUI or the handle to
%      the existing singleton*.
%
%      DOUBLEM_GUI('Property','Value',...) creates a new DOUBLEM_GUI using the
%      given property value pairs. Unrecognized properties are passed via
%      varargin to DoubleM_GUI_OpeningFcn.  This calling syntax produces a
%      warning when there is an existing singleton*.
%
%      DOUBLEM_GUI('CALLBACK') and DOUBLEM_GUI('CALLBACK',hObject,...) call the
%      local function named CALLBACK in DOUBLEM_GUI.M with the given input
%      arguments.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help DoubleM_GUI

% Last Modified by GUIDE v2.5 19-Sep-2024 15:27:10

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @DoubleM_GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @DoubleM_GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
   gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


%% --- Executes just before DoubleM_GUI is made visible.
function DoubleM_GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   unrecognized PropertyName/PropertyValue pairs from the
%            command line (see VARARGIN)

% Choose default command line output for DoubleM_GUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes DoubleM_GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);

img = imread('Pantograph_2M_Real.jpg');
axes(handles.axes5);
imshow(img);

img = imread('Pantograph_2M.png');
axes(handles.axes6);
imshow(img);



%% --- Outputs from this function are returned to the command line.
function varargout = DoubleM_GUI_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



%% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

 % 绘制数据
axes(handles.axes1);
plot(handles.time1, handles.signal_WO, 'k', 'LineWidth', 1.7);
hold on;
plot(handles.time1, handles.signal_LQR, 'y-.', 'LineWidth', 1.6);
hold on;
plot(handles.time1, handles.signal_SMC, 'm:', 'LineWidth', 1.3);
hold on;
plot(handles.time2, handles.signal_Ours, 'r', 'LineWidth', 1.55);
hold off;
legend('WO', 'LQR', 'SMC', 'Ours');
xlabel('Time/S');
ylabel('Fpc/N');
xlim([0,9]);

axes(handles.axes2); % 替换 'axes_plot' 为实际的 axes 控件的 Tag
plot(handles.time1, handles.signal_WO, 'k', 'LineWidth', 1.6);
hold on;
plot(handles.time2, handles.signal_DDPG, 'g-', 'LineWidth', 1.25);
hold on;
plot(handles.time2, handles.signal_HERDDPG, 'b-.', 'LineWidth', 1.35);
hold on;
plot(handles.time2, handles.signal_Ours, 'r', 'LineWidth', 1.5);
hold off;
legend('WO', 'DDPG', 'HER-DDPG', 'Ours');
xlabel('Time/S');
ylabel('Fpc/N');
xlim([0,9]);

axes(handles.axes3); % 替换 'axes_plot' 为实际的 axes 控件的 Tag
plot(handles.time3, handles.signal_Ours60, 'k', 'LineWidth', 1.4);
hold on;
plot(handles.time3, handles.signal_Ours80, 'g-', 'LineWidth', 1.4);
hold on;
plot(handles.time3, handles.signal_Ours100, 'r', 'LineWidth', 1.4);
hold off;
legend('Ours at 60km/h', 'Ours at 80km/h', 'Ours at 100km/h');
xlabel('Time/S');
ylabel('Fpc/N');
xlim([0,9]);

axes(handles.axes4); % 替换 'axes_plot' 为实际的 axes 控件的 Tag
plot(handles.time4, handles.signal_WODisturbance, 'k', 'LineWidth', 1.4);
hold on;
plot(handles.time4, handles.signal_disturbance, 'r', 'LineWidth', 1.4);
hold off;
legend('无扰动', '扰动');
xlabel('Time/S');
ylabel('Fpc/N');
xlim([0,9]);

%% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% 假设 Excel 文件中有两列数据，第一列是时间，第二列是信号值
frequencyWO = handles.frequencyWO;
magnitudeWO = handles.magnitudeWO;
frequencyLQR = handles.frequencyLQR;
magnitudeLQR = handles.magnitudeLQR;
frequencySMC = handles.frequencySMC;
magnitudeSMC = handles.magnitudeSMC;
frequencyOurs = handles.frequencyOurs;
magnitudeOurs = handles.magnitudeOurs;

frequencyWO2 = handles.frequencyWO2 ;
magnitudeWO2 = handles.magnitudeWO2 ;
frequencyDDPG = handles.frequencyDDPG ;
magnitudeDDPG = handles.magnitudeDDPG ;
frequencyHERDDPG = handles.frequencyHERDDPG ;
magnitudeHERDDPG = handles.magnitudeHERDDPG ;
frequencyOurs2 = handles.frequencyOurs2 ;
magnitudeOurs2 = handles.magnitudeOurs2 ;

frequency_60 = handles.frequency_60 ;
magnitude_60 = handles.magnitude_60 ;
frequency_80 = handles.frequency_80 ;
magnitude_80 = handles.magnitude_80 ;
frequency_100 = handles.frequency_100 ;
magnitude_100 = handles.magnitude_100 ;

frequencyWO_RD = handles.frequencyWO_RD ;
magnitudeWO_RD = handles.magnitudeWO_RD ;
frequencyOurs_RD = handles.frequencyOurs_RD;
magnitudeOurs_RD = handles.magnitudeOurs_RD ;
  
% 在 GUI 的 axes 控件上绘制图像
axes(handles.axes1); % 替换 'axes_plot' 为实际的 axes 控件的 Tag
plot(frequencyWO, magnitudeWO*100, 'k','LineWidth', 1.5) 
hold on;
plot(frequencyLQR,magnitudeLQR*100, 'y-.', 'LineWidth', 1.4) 
hold on;
plot(frequencySMC,magnitudeSMC*100, 'm-.',  'LineWidth', 1.3) 
hold on;
plot(frequencyOurs,magnitudeOurs*100, 'LineWidth', 1.6, 'Color', 'r') 
hold off;
legend('WO', 'LQR', 'SMC', 'Ours');
xlabel('Frequency/Hz');
ylabel('Magnitude/N');
xlim([0,9]);
ylim([0,20]);

axes(handles.axes2); % 替换 'axes_plot' 为实际的 axes 控件的 Tag
plot(frequencyWO2, magnitudeWO2*100, 'k', 'LineWidth', 1.6) 
hold on;
plot(frequencyDDPG,magnitudeDDPG*100, 'g-', 'LineWidth', 1.25) 
hold on;
plot(frequencyHERDDPG,magnitudeHERDDPG*100, 'b-.', 'LineWidth', 1.35) 
hold on;
plot(frequencyOurs2,magnitudeOurs2*100, 'LineWidth', 1.6, 'Color', 'r') 
hold off;
legend('WO', 'DDPG', 'HERDDPG', 'Ours');
xlabel('Frequency/Hz');
ylabel('Magnitude/N');
xlim([0,9]);
ylim([0,20]);

axes(handles.axes3); % 替换 'axes_plot' 为实际的 axes 控件的 Tag
plot(frequency_60, magnitude_60*100, 'g', 'LineWidth', 1.4) 
hold on;
plot(frequency_80,magnitude_80*100, 'LineWidth', 1.4, 'Color', 'r') 
hold on;
plot(frequency_100, magnitude_100*100, 'b', 'LineWidth', 1.4) 
hold off;
legend('60km/h', '80km/h','100km/h');
xlabel('Frequency/Hz');
ylabel('Magnitude/N');
xlim([0,9]);
ylim([0,20]);

axes(handles.axes4); % 替换 'axes_plot' 为实际的 axes 控件的 Tag
plot(frequencyWO_RD, magnitudeWO_RD*100, 'k', 'LineWidth', 1.4) 
hold on;
plot(frequencyOurs_RD,magnitudeOurs_RD*100, 'LineWidth', 1.4, 'Color', 'r') 
hold off;
legend('WO存在扰动', 'Ours抑制扰动');
xlabel('Frequency/Hz');
ylabel('Magnitude/N');
xlim([0,9]);
ylim([0,30]);



%% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


[filename, pathname] = uigetfile({'*.xlsx;*.xls'}, 'Select Excel file');
if isequal(filename, 0)
    disp('User selected Cancel');
else
    fullfilename = fullfile(pathname, filename);
    disp(['User selected ', fullfilename]);
    
    % 读取 Excel 文件
    data = readtable(fullfilename);
    
    % 保存数据到 handles 结构
    handles.time1 = (data.Time1) * 1;
    handles.time2 = (data.Time2);
    handles.time3 = (data.Time3);
    handles.time4 = (data.Time4);
    handles.signal_WO = (data.WO);
    handles.signal_LQR = (data.LQR);
    handles.signal_SMC = (data.SMC);
    handles.signal_DDPG = (data.Observations_DDPG) * 100;
    handles.signal_HERDDPG = (data.Observations_HERDDPG) * 100;
    handles.signal_Ours = (data.Observations_LQRHERDDPG) * 100;
    handles.signal_Ours60 = (data.Observations_LQRHERDDPG_60) * 100;
    handles.signal_Ours80 = (data.Observations_LQRHERDDPG_80) * 100;
    handles.signal_Ours100 = (data.Observations_LQRHERDDPG_100) * 100;
    handles.signal_WODisturbance = (data.WithoutControl_RD) * 100;
    handles.signal_disturbance = (data.Observations_RD) * 100;

    %保存FFT文件结果
    handles.frequencyWO = data.FrequencyWO;
    handles.magnitudeWO = data.MagnitudeWO;
    handles.frequencyLQR = data.FrequencyLQR;
    handles.magnitudeLQR = data.MagnitudeLQR;
    handles.frequencySMC = data.FrequencySMC;
    handles.magnitudeSMC = data.MagnitudeSMC;
    handles.frequencyOurs = data.FrequencyOurs;
    handles.magnitudeOurs = data.MagnitudeOurs;

    handles.frequencyWO2 = data.FrequencyWO2;
    handles.magnitudeWO2 = data.MagnitudeWO2;
    handles.frequencyDDPG = data.FrequencyDDPG;
    handles.magnitudeDDPG = data.MagnitudeDDPG;
    handles.frequencyHERDDPG = data.FrequencyHERDDPG;
    handles.magnitudeHERDDPG = data.MagnitudeHERDDPG;
    handles.frequencyOurs2 = data.FrequencyOurs2;
    handles.magnitudeOurs2 = data.MagnitudeOurs2;

    handles.frequency_60 = data.Frequency_60;
    handles.magnitude_60 = data.Magnitude_60;
    handles.frequency_80 = data.Frequency_80;
    handles.magnitude_80 = data.Magnitude_80;
    handles.frequency_100 = data.Frequency_100;
    handles.magnitude_100 = data.Magnitude_100;

    handles.frequencyWO_RD = data.FrequencyWO_RD;
    handles.magnitudeWO_RD = data.MagnitudeWO_RD;
    handles.frequencyOurs_RD = data.FrequencyOurs_RD;
    handles.magnitudeOurs_RD = data.MagnitudeOurs_RD;
    
    % 更新 handles 结构
    guidata(hObject, handles);
    
%     % 绘制数据
%     axes(handles.axes1);
%     plot(handles.time1, handles.signal_WO, 'k', 'LineWidth', 1.7);
%     hold on;
%     plot(handles.time1, handles.signal_LQR, 'y-.', 'LineWidth', 1.6);
%     hold on;
%     plot(handles.time1, handles.signal_SMC, 'm:', 'LineWidth', 1.3);
%     hold on;
%     plot(handles.time2, handles.signal_Ours, 'r', 'LineWidth', 1.55);
%     hold off;
%     legend('WO', 'LQR', 'SMC', 'Ours');
%     xlabel('Time/S');
%     ylabel('Fpc/N');
%     xlim([0,9]);
% 
%     axes(handles.axes2); % 替换 'axes_plot' 为实际的 axes 控件的 Tag
%     plot(handles.time1, handles.signal_WO, 'k', 'LineWidth', 1.6);
%     hold on;
%     plot(handles.time2, handles.signal_DDPG, 'g-', 'LineWidth', 1.25);
%     hold on;
%     plot(handles.time2, handles.signal_HERDDPG, 'b-.', 'LineWidth', 1.35);
%     hold on;
%     plot(handles.time2, handles.signal_Ours, 'r', 'LineWidth', 1.5);
%     hold off;
%     legend('WO', 'DDPG', 'HER-DDPG', 'Ours');
%     xlabel('Time/S');
%     ylabel('Fpc/N');
%     xlim([0,9]);
% 
%     axes(handles.axes3); % 替换 'axes_plot' 为实际的 axes 控件的 Tag
%     plot(handles.time3, handles.signal_Ours60, 'k', 'LineWidth', 1.4);
%     hold on;
%     plot(handles.time3, handles.signal_Ours80, 'g-', 'LineWidth', 1.4);
%     hold on;
%     plot(handles.time3, handles.signal_Ours100, 'r', 'LineWidth', 1.4);
%     hold off;
%     legend('Ours at 60km/h', 'Ours at 80km/h', 'Ours at 100km/h');
%     xlabel('Time/S');
%     ylabel('Fpc/N');
%     xlim([0,9]);
% 
%     axes(handles.axes4); % 替换 'axes_plot' 为实际的 axes 控件的 Tag
%     plot(handles.time4, handles.signal_WODisturbance, 'k', 'LineWidth', 1.4);
%     hold on;
%     plot(handles.time4, handles.signal_disturbance, 'r', 'LineWidth', 1.4);
%     hold off;
%     legend('无扰动', '扰动');
%     xlabel('Time/S');
%     ylabel('Fpc/N');
%     xlim([0,9]);
end



%% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[filename, pathname] = uigetfile({'*.xlsx;*.xls'}, 'Select Excel file');
if isequal(filename, 0)
    disp('User selected Cancel');
else
    fullfilename = fullfile(pathname, filename);
    disp(['User selected ', fullfilename]);
    
    % 读取 Excel 文件
    data = readtable(fullfilename);
    
    % 格式化数据，显示小数点后两位
    formattedData = cell(size(data));
    for row = 1:size(data, 1)
        for col = 1:size(data, 2)
            if isnumeric(data{row, col})
                % 对数值数据进行格式化，保留两位小数
                formattedData{row, col} = sprintf('%.2f', data{row, col});
            else
                % 非数值数据保持不变
                formattedData{row, col} = data{row, col};
            end
        end
    end
    
    % 将格式化后的数据设置到 uitable 控件
    set(handles.uitable1, 'Data', formattedData);
    
    % 更新 handles 结构
    guidata(hObject, handles);
end
